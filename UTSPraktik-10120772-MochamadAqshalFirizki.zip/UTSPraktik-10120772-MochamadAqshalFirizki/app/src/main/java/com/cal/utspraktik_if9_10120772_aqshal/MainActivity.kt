package com.cal.utspraktik_if9_10120772_aqshal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cal.utspraktik_if9_10120772_aqshal.R

/**
 * Tanggal Pengerjaan : 25/05/2023
 * Nim    : Mochamad Aqshal Firizki
 * NAMA   : 10120772
 * KELAS  : IF-9
 **/

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}